var FirstComponent = React.createClass({
    render: function(){
        return (
            <div>
                <h2>Some thing here</h2>
                <p>Something else</p>
            </div>
            
        )
    }
})

var obj = React.createElement(FirstComponent, {});
ReactDOM.render(obj, document.getElementById('content'))