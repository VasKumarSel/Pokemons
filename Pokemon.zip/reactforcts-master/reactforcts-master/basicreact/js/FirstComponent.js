'use strict';

var FirstComponent = React.createClass({
    displayName: 'FirstComponent',

    render: function render() {
        return React.createElement(
            'div',
            null,
            React.createElement(
                'h2',
                null,
                'Some thing here'
            ),
            React.createElement(
                'p',
                null,
                'Something else'
            )
        );
    }
});

var obj = React.createElement(FirstComponent, {});
ReactDOM.render(obj, document.getElementById('content'));