'use strict';

var Badge = React.createClass({
    displayName: 'Badge',

    getInitialState: function getInitialState() {
        console.log('Set Initial State');
        return { count: 0 };
    },

    incrementCount: function incrementCount() {
        console.log('click event captured..');
        var newcount = this.state.count + 1;
        this.setState({ count: newcount });
    },

    render: function render() {
        return React.createElement(
            'button',
            { className: 'btn btn-primary', type: 'button', onClick: this.incrementCount },
            this.props.caption,
            ' ',
            React.createElement(
                'span',
                { className: 'badge' },
                this.state.count
            )
        );
    }
});

var obj = React.createElement(Badge, { caption: "Sent" });
ReactDOM.render(obj, document.getElementById('content'));
// ReactDOM.render(<Badge caption="Sent"/>, document.getElementById('content1'))

ReactDOM.render(React.createElement(Badge, { caption: 'Inbox' }), document.getElementById('content1'));