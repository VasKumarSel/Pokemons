'use strict';

var count = React.createClass({
    displayName: 'count',

    getInitialState: function getInitialState() {
        console.log('Set Initial State');
        return { count: 0,
            val: {}
        };
    },

    incrementCount: function incrementCount() {
        console.log('click event captured..');
        var newcount = this.state.count + 1;
        this.setState({ count: newcount });
    },
    update: function update() {
        var root = "http://192.168.1.3:8080/reactforcts-master/count/count.json";
        $.ajax({
            url: root,
            method: 'GET'
        }).then(function (data) {
            this.state.val = data.count;
        });

        console.log(this.state);
    },
    render: function render() {
        return React.createElement(
            'div',
            null,
            React.createElement(
                'h2',
                null,
                'Hii bddy dgfsgf'
            ),
            React.createElement(
                'h1',
                null,
                'dhjfhd'
            ),
            React.createElement(
                'button',
                { onClick: this.incrementCount },
                'Hii'
            ),
            React.createElement(
                'button',
                { onClick: this.update },
                this.state.val
            )
        );
    }
});

var obj = React.createElement(count, {});

ReactDOM.render(obj, document.getElementById('root'));