import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {createStore,applyMiddleware} from 'redux';
import {Provider} from 'react-redux';
import {combineReducers} from 'redux';
import UserReducer from '../reducer/UserReducer';
import UserDetails from './UserDetails';
import UserName from './UserName';
import getDetails from '../reducer/GetReducer';
import thunk from 'redux-thunk';

export const combinedReducer = combineReducers({users : UserReducer,
                                                details : getDetails});

const store = createStore(combinedReducer,applyMiddleware(thunk));
console.log("ffh",store.getState())

class App extends Component{
    render(){
        return(
        <div>
            <h2>UserName:</h2>
            <UserName/>
            <h2>UserDetails:</h2>
            <UserDetails/>
        </div>
    )
    }
}

// var obj = React.createElement(App, {});

ReactDOM.render(<Provider store={store}>
                    <App/>
                </Provider>,document.getElementById('app'))

