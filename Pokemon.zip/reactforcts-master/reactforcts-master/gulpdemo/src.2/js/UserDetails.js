import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as Actions from '../actions/actions';
import {get, loadData} from '../actions/actions';
import UserName from './UserName';


class UserDetails extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            values : []
        }
    }

    componentWillMount(){
        this.props.loadData(); 
    }

    componentWillReceiveProps(nextProps){
        console.log("dhfwghw",nextProps.details)
        this.setState({values : nextProps.details})
    }
    
    render(){
        var Users = this.state.values.map((user1)=>(<li key={user1.id}>{user1.firstname}  {user1.lastname}  </li>));

        return(
            <div>
               <p>the name issdssd c</p>
                {Users} 
            </div>
        )
    }
}
 

function mapStateToProps(state){
    return{
        details : state.details
    }
}

// function matchDispatchToProps(dispatch){
//     return {
//         actions : dispatch(loadData())
//     }
// }




export default connect(mapStateToProps,Actions)(UserDetails)