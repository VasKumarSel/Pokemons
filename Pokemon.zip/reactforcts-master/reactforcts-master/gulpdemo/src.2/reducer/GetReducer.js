export default function getDetails(state={},action){
    
    switch(action.type){
        case "GET":
        return action.users
        break;

        default: return state
    }
    
}