import fetch from 'isomorphic-fetch';
import axios from 'axios';

function fetchData(){
    axios.get("http://localhost:4000/todo")
    .then(function(response){
        console.log(response)
    })
    .catch(function(error){
        console.log(error)
    })
}

export function get(users){
    console.log("eyryye",users)
    return{
        type: "GET",
        users
    }
}

export function loadData(){
    return (dispatch)=>{
        return fetch("http://localhost:4000/todo")
        .then(users=> users.json())
        .then(users=>dispatch(get(users))
         )
        .catch((error)=>{
            throw(error)
        })
    }
}