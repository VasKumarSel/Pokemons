var obj = React.createElement(ThumbnailList, {});
ReactDOM.render(obj, document.getElementById('mount-point'))
