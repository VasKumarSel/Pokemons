import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Button from "./Button";
import ListItems from "./ListItems";


class DropDown extends Component{
    constructor(props){
        super();
        this.state = {
            show : false,
            caption: "Technology",
            cources : ["JS","Angular","Ajax"]
        }
    }

    showDown(){
        console.log("show")
        this.setState({
            show : !this.state.show
        })
    }

    handleItemClick(item){
        console.log("the course is",item)
        this.setState({
            show:true,
            todo: item
        })
    }

    handleChange(event){
        this.setState({
            todo:event.target.value
        })
    }

    displayText(){
        console.log("the value is",this.state.todo)
    }
    render(){
        var list = this.state.cources.map((cource,i)=> <ListItems  whenClick={this.handleItemClick.bind(this)} key={i} text={cource}></ListItems>)
        return(
            <div>
                <div class="dropdown">
                <input type="text" onChange={this.handleChange.bind(this)} value={this.state.todo}/>
                <button onClick={this.displayText.bind(this)}>Display</button>
                     <br/>     
                    <Button whenClick={this.showDown.bind(this)} title={this.state.caption || this.props.title}/>
                    <ul   class={this.state.show ? "dropdown-menu show" : "dropdown-menu" } aria-labelledby="dropdownMenu1">
                        {list}
                    </ul>
                </div>
                <div>
                     
                </div>    
            </div>
        );
    }
}
export default DropDown;
var obj = React.createElement(DropDown,{})

ReactDOM.render(obj,document.getElementById('drop'))