import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class Button extends Component{
    
    
    render(){
        return(
            <button onClick={this.props.whenClick} 
                    class="btn btn-default dropdown-toggle" 
                    type="button" id="dropdownMenu1" data-toggle="dropdown" 
                    aria-haspopup="true" aria-expanded="true">
                                {this.props.title}
            <span class="caret"></span>
            </button>
        );
    }
}

export default Button;