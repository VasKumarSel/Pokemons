import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';

class Sample extends Component{
    constructor(){
        super();
        this.state = {
            datas : [],
            item:[]
        }
    }

    removeData(){
        axios.delete("http://localhost:4000/del_user")
        .then((response)=>{
            this.setState({
                datas : this.state.datas.splice(1)
            })
        })
        .catch((error)=>{
            console.log(error)
        })
        
    }

    // addData(){
    //     var add = this.state.datas;
    //     add.push("new value"); 
    //     this.setState({
    //         datas : add
    //     })
    // }

    handleChange(event){
        this.setState({
            item: event.target.value
        })
    }    

    addToTheList(){
        //var add = this.state.datas;
        console.log("the name is",this.state.item)
        this.setState({
            item : this.state.datas.push(this.state.item),
            
        })
    }
    
    postDetails(){
        axios.post("http://localhost:4000/todo" ,{
            name: "Akshay",
            name1:"Ganesh"
        })
        .then((response)=>{
            console.log(response)
            this.setState({
                datas : response.data
            })
        }) 
        .catch((error)=>{
            console.log(error)
        })    
    }

    
    componentWillMount(){
        axios.get("http://localhost:4000/todo")
        .then((response)=>{
            this.setState({
                datas : response.data
            })
        }) 
        .catch((error)=>{
            console.log(error)
        })    
    }
    render(){
        var list = this.state.datas.map((data,i)=>
        <div>
        <ul class="list-group">
        <li key={i} class="list-group-item">{data}</li> </ul>
        <button onClick={this.removeData.bind(this)} type="button" class="btn btn-danger">-</button>
        </div>)
        return(
            <div >
                <p>List of Names</p>
                {list}
                <br/>           
                <button onClick={this.addToTheList.bind(this)} type="button" class="btn btn-primary">AddOn</button>
                <input type="text" onChange={this.handleChange.bind(this)} placeholder="Enter the Name"/><br/><br/>
                <button onClick={this.postDetails.bind(this)} type="button" class="btn btn-primary">Post</button>
            </div>
        );
    }
}

var obj = React.createElement(Sample,{})

ReactDOM.render(obj,document.getElementById('sample'))