export default function() 
{
    
    return[
        {   "id": 1, 
        "firstname": "Kamal",
		"lastname": "Haasan",
		"image": "https://akm-img-a-in.tosshub.com/indiatoday/images/story/201707/kamal-hassan_647_082116071527_071917115444_0.jpg",
        "link": "http://iviewsource.com",
        "description": "Universal Star"
    },
    {   "id": 2, 
        "firstname": "Rajni",
		"lastname": "Kanth",
		"image": "https://qph.ec.quoracdn.net/main-qimg-5a353a8bfa444ea870255168df837648.webp",
        "link": "http://iviewsource.com",
        "description": "Super Star"
    } ,
    {   "id": 3, 
        "firstname": "Ajith",
		"lastname": "Kumar",
		"image": "http://www.ajithfans.com/article-uploads/2008/11/ajith-kumar.jpg",
        "link": "http://iviewsource.com",
        "description": "Ultimate Star"
	}   

    ]

};

