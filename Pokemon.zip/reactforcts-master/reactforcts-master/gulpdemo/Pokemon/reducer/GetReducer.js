const initialState={
    pokemons:[]
}

export default function getDetails(state=initialState,action){
    
    switch(action.type){
        case "GET":
            let pokemons = action.users;
        return  pokemons
        break;
        
        // case "FILTER":
        //  let Items = state.pokemons.name.filter((poke)=>{
        //      if(poke.name.includes(action.search)){
        //          return true;
        //      }
        //      return false;
        //  })  
        //  return Items;
        //  break;

        default: return state;
    }
    
}