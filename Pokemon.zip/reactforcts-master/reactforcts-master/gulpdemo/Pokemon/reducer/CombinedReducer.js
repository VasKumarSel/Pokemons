import {combineReducers} from 'redux';
import UserReducer from './UserReducer';
import {getDetails} from './GetReducer'

export const combinedReducer = combineReducers(
    {
        users : UserReducer,
        details : getDetails
    }
);

// export default combinedReducer()
// {    
//     combineReducers({users : UserReducer})
// }
