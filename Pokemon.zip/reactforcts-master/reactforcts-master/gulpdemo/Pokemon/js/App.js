import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {createStore,applyMiddleware} from 'redux';
import {Provider} from 'react-redux';
import {combineReducers} from 'redux';
import UserReducer from '../reducer/UserReducer';
import Pokemon from './Pokemon';
import Search from './Search';
import getDetails from '../reducer/GetReducer';
import thunk from 'redux-thunk';

export const combinedReducer = combineReducers({users : UserReducer,
                        pokemons : getDetails});

const store = createStore(combinedReducer,applyMiddleware(thunk));
console.log("ffh",store.getState())

class App extends Component{
    render(){
        return(
        <div>
          <Pokemon/>
        </div>
    )
    }
}

// var obj = React.createElement(App, {});

ReactDOM.render(<Provider store={store}>
                    <App/>
                </Provider>,document.getElementById('app2'))

