import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as Actions from '../actions/actions';
import {get, loadData} from '../actions/actions';
import Search from './Search';

class Pokemon extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            values : [],
            search : []
        }
        this.onSearch = this.onSearch.bind(this);
       // this.onClear = this.onClear.bind(this);
    }

    componentWillMount(){
       this.props.loadData(); 
    }

    componentWillReceiveProps(nextProps){
        console.log("dhfwghw",nextProps.pokemons)
        this.setState({values : nextProps.pokemons})
    }

    onSearch(data){
        console.log("the search",data)
        let selected = this.state.values.filter((poke)=>{ 
            return poke.name.toUpperCase().includes(data.toUpperCase())
      })
            this.setState({values : selected})
    }

    

    renderPokemon(){
        var pokemons = this.state.values.map((pokemon)=>
            
        (<li key={pokemon.id} class="lists">
            <button class="click" 
                style={{
                    backgroundImage: `url(${`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.id}.png`})`
                  }}>
                </button> <p class="names">{pokemon.name}</p></li>));
        return(
            <div class="pokemon">{pokemons}</div>
        )
    }

    

    render(){
     return(
        <div class="liststyle">
           <Search whenChange={this.onSearch} />
           <br/>
            {this.renderPokemon()} 
        </div>
        )
    }
}

function mapStateToProps(state){
    return{
        pokemons : state.pokemons
    }
}

export default connect(mapStateToProps,Actions)(Pokemon)