import React from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import * as Actions from '../actions/actions';
import {get, loadData} from '../actions/actions';
import Pokemon from './Pokemon';

class Search extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            values : []
        } 
        this.onchange = this.onchange.bind(this);
       // this.clear = this.clear.bind(this);
    }

    // componentWillMount(){
       
    //     this.props.loadData(); 
    // }

    // componentWillReceiveProps(nextProps){
    //     console.log("dhfwghw",nextProps.details)
    //     this.setState({values : nextProps.details})
    // }
    onchange(e){
        this.props.whenChange(e.target.value)
        //this.setState({values:e.target.value})
    }

    // clear(e){
    //     if(e.target.values == ''){
    //     this.props.whenClear(e.target.value)
    //     }
    // }

    render(){
        return(
            <div class="search">
                <input type="text" onChange={this.onchange}/>
                {this.state.values}
                </div>
        )
    }
}

function mapStateToProps(state){
    return{
        details : state.details
    }
}

export default connect(mapStateToProps,Actions)(Search)