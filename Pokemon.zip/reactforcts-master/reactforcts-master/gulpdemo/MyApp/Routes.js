import React, { Component } from 'react';
import {Route,Link,Switch} from 'react-router-dom';
import Login from "./Components/Login";
import Profile from "./Components/Profile";
import Error from "./Components/Error";
class Routes extends Component {
   render() {
        return (
            <div>
            <Link to="/">Login</Link> | <Link to="/next">Profile</Link> 
            <hr/>
                <Link to="/next/Chennai">Chennai</Link> | <Link to="/next/Delhi">Delhi</Link>
                <hr/>
            <Switch>
            <Route exact path="/" component={Login}/>
            <Route exact path="/next" component={Profile}/>
            <Route path="/next/:city" component={Profile}/>
            <Route path="/oops" component={Error}/>
            </Switch>
            </div>
        );
    }
}

export default Routes;
