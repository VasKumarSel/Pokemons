import React, { Component } from 'react';
import axios from 'axios';

class Login extends Component {
    constructor(){
        super();
        this.state={
            id: '',
            pwd:''
        }
     }

     getId(e){
         this.setState({
            id :e.target.value
         })
         
     }
     
     getPass(e){
         this.setState({
             pwd:e.target.value
         })
         console.log("ID is",this.state.pwd)
     }
     

     postIt(){
       // console.log(this.props);

        fetch('http://localhost:4000/app', {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            method: "POST",
            body: JSON.stringify({ id: this.state.id, pwd: this.state.pwd })
        })
            .then((res) => res.json())
            .then((data) => {
                
                if(data.get){
                    //Navigate to next page
                    this.props.history.push('/next')
                }
                else{
                    //Show up error Messsage
                    this.props.history.push('/oops')
                }
                // this.setState({ todos: data, todo:'' });
            })
    }
    render() {
        
        return (
            <div>
                <h2>LogIn</h2><br/>
                <input type="text" placeholder="Enter id" onChange={this.getId.bind(this)}/><br/><br/> 
                <input type="text" placeholder="Enter pass" onChange={this.getPass.bind(this)}/><br/><br/> 
               <button onClick={this.postIt.bind(this)}>Sign In</button>
            </div>
        );
    }
}

export default Login;