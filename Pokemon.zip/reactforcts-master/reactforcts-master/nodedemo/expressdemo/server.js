var express = require('express')
var bodyParser = require('body-parser')
var cors = require('cors')
var app = express()


app.use(cors());
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())
 
var todos= [
  
  {
     "id":1, 
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/1\/",
    "name": "bulbasaur"
},
{
    "id":2,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/2\/",
    "name": "ivysaur"
},
{
    "id":3,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/3\/",
    "name": "venusaur"
},
{
    "id":4,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/4\/",
    "name": "charmander"
},
{
    "id":5,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/5\/",
    "name": "charmeleon"
},
{
    "id":6,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/6\/",
    "name": "charizard"
},
{
    "id":7,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/7\/",
    "name": "squirtle"
},
{
    "id":8,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/8\/",
    "name": "wartortle"
},
{
    "id":9,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/9\/",
    "name": "blastoise"
},
{
    "id":10,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/10\/",
    "name": "caterpie"
},
{
    "id":11,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/11\/",
    "name": "metapod"
},
{
    "id":12,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/12\/",
    "name": "butterfree"
},
{
    "id":13,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/13\/",
    "name": "weedle"
},
{
    "id":14,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/14\/",
    "name": "kakuna"
},
{
    "id":15,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/15\/",
    "name": "beedrill"
},
{
    "id":16,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/16\/",
    "name": "pidgey"
},
{
    "id":17,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/17\/",
    "name": "pidgeotto"
},
{
    "id":18,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/18\/",
    "name": "pidgeot"
},
{
    "id":19,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/19\/",
    "name": "rattata"
},
{
    "id":20,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/20\/",
    "name": "raticate"
},
{
    "id": 21,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/21\/",
    "name": "spearow"
},
{
    "id": 22,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/22\/",
    "name": "fearow"
},
{
    "id": 23,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/23\/",
    "name": "ekans"
},
{
    "id": 24,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/24\/",
    "name": "arbok"
},
{
    "id": 25,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/25\/",
    "name": "pikachu"
},
{
    "id": 26,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/26\/",
    "name": "raichu"
},
{
    "id": 27,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/27\/",
    "name": "sandshrew"
},
{
    "id": 28,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/28\/",
    "name": "sandslash"
},
{
    "id": 29,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/29\/",
    "name": "nidoran-f"
},
{
    "id": 30,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/30\/",
    "name": "nidorina"
},
{
    "id": 31,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/31\/",
    "name": "nidoqueen"
},
{
    "id": 32,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/32\/",
    "name": "nidoran-m"
},
{
    "id": 33,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/33\/",
    "name": "nidorino"
},
{
    "id": 34,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/34\/",
    "name": "nidoking"
},
{
    "id": 35,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/35\/",
    "name": "clefairy"
},
{
    "id": 36,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/36\/",
    "name": "clefable"
},
{
    "id": 37,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/37\/",
    "name": "vulpix"
},
{
    "id": 38,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/38\/",
    "name": "ninetales"
},
{
    "id": 39,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/39\/",
    "name": "jigglypuff"
},
{
    "id": 40,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/40\/",
    "name": "wigglytuff"
},
{
    "id": 41,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/41\/",
    "name": "zubat"
},
{
    "id": 42,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/42\/",
    "name": "golbat"
},
{
    "id": 43,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/43\/",
    "name": "oddish"
},
{
    "id": 44,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/44\/",
    "name": "gloom"
},
{
    "id": 45,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/45\/",
    "name": "vileplume"
},
{
    "id": 46,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/46\/",
    "name": "paras"
},
{
    "id": 47,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/47\/",
    "name": "parasect"
},
{
    "id": 48,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/48\/",
    "name": "venonat"
},
{
    "id": 49,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/49\/",
    "name": "venomoth"
},
{
    "id": 50,
    "url": "https:\/\/pokeapi.co\/api\/v2\/pokemon\/50\/",
    "name": "diglett"
}
  
]
var det = []

app.get('/todo', function (req, res) {
  res.json(todos);
})

app.post('/todo', function (req, res) {
    var tds = req.body

    todos.push(tds.name,tds.name1)
    res.json(todos);
  })

// app.delete('/todos',function(req,res){
//   console.log("Deleted")
//   res.send("hello world");
// })
app.post('/app', function (req, res) {
  var id = req.body.id
  var pwd = req.body.pwd
  if(id == pwd){
    res.json({get: true})
  }
  else{
    res.json({get:false});
  }
})

app.delete('/del_user', function (req, res) {
  console.log("Got a DELETE request for /del_user");
  res.json(todos);
})
app.get('/weather', function (req, res) {
  res.json({"currentTemp" : 25})
})

app.post('/', function (req, res) {
    res.send('Hello World')
  })
 
app.listen(4000)