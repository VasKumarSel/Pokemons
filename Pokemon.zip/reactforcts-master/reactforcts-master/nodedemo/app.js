

var sum = function(x,y){
    return x+y;
}
module.exports = sum;